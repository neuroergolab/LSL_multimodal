disp('Loading library...');
lib = lsl_loadlib();
disp('Displaying library version');
version = lsl_library_version(lib)
